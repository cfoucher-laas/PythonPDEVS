# Copyright 2014 Modelling, Simulation and Design Lab (MSDL) at 
# McGill University and the University of Antwerp (http://msdl.cs.mcgill.ca/)
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Defines the colors to be used when drawing the model, 
should be colors that are understood by GraphViz. 
If more nodes are used than colors are provided here, 
they will be shown in white.
"""
colors = [
"red", 
"green", 
"blue", 
"yellow", 
"cyan", 
"magenta", 
"azure", 
"violet", 
"rose", 
"orange", 
"chartreuse", 
"vermilion", 
"amber", 
"viridian", 
"indigo", 
"aliceblue", 
"darkkhaki", 
"darkgreen", 
"darkviolet", 
"deepskyblue", 
"aquamarine", 
"floralwhite", 
"deeppink", 
"dimgray", 
"dodgerblue", 
"firebrick", 
"forestgreen", 
"gold", 
"goldenrod", 
"greenyellow", 
"lightblue", 
"lawngreen", 
"lavender", 
"khaki", 
"ivory", 
"linen", 
"maroon",
"lemonchiffon",
"orchid",
"salmon",
"seagreen",
"skyblue",
"sienna",
"wheat",
"turquoise",
"tomato",
"tan",
"steelblue",
"slategray",
"slateblue"
]
